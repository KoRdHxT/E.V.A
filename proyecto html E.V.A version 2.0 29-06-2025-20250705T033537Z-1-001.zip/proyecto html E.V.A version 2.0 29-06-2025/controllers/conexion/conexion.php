<?php 
    /* Se realiza la conexión a la base de datos*/
    $username = "root"; 
    $password = ""; 
    $database = "ver"; 
    $mysqli = new mysqli("127.0.0.1", $username, $password, $database); 

?>